# Extracción del motor de Activepieces

## Estado

**Primer hito implementado:** biblioteca CommonJS y CLI que ejecutan cadenas de piezas locales, guardan checkpoints y reanudan una ejecución interrumpida sin la API de Activepieces, Redis, PostgreSQL ni editor. Usan el intérprete, contexto, resolución de propiedades y ejecutor de piezas upstream, con adaptadores inyectados durante la compilación. El clon de referencia permanece sin modificaciones.

Hay 385 archivos preservados de ocho paquetes, con licencia original, commit y hashes de procedencia. Nueve pruebas pasan, incluida muerte abrupta del proceso en el segundo paso y recuperación sin repetir el primero. Se verificó la ejecución local con conexiones de red bloqueadas. La paridad completa con Activepieces todavía no está implementada.

Base examinada: Activepieces `2d5a47708c87e3ce17116d2d4b34d4d1208e8cd2` (proyecto 0.92.0, motor 0.7.0). El código del motor está cubierto por MIT según la licencia raíz; los directorios Enterprise y las dependencias requieren tratamiento separado.

## Decisión propuesta

Crear un fork de extracción por etapas, preservando primero las semánticas y pruebas del motor. Mantener compatibilidad inicial con el formato de flujos y el SDK de piezas. Definir una API propia para usarlo desde Node o desde un servicio. Reducir las dependencias después de alcanzar paridad verificable.

El primer objetivo funcional ya ejecuta un flujo JSON con una pieza local, devuelve su resultado y guarda su estado sin llamar a la API de Activepieces ni necesitar Redis, PostgreSQL o su editor. Esos servicios pueden añadirse como adaptadores cuando sean necesarios.

## Uso reproducible

Probado en Windows con Node 24.16.0. Las dependencias están fijadas mediante `package-lock.json`; las fuentes necesarias están en `vendor`, por lo que compilar y ejecutar no requiere el clon original. La instalación inicial de npm sí necesita acceso al registro.

Desde este directorio:

```powershell
npm ci --ignore-scripts --no-audit --no-fund
npm run verify-source
npm run lint-dev
npm run build
npm test
npm run demo
```

La demo genera un identificador de ejecución, devuelve `MOTOR INDEPENDIENTE` y guarda el estado en `.local-state`. Para ejecutar y reanudar con identificador elegido:

```powershell
node dist/cli.cjs examples/flow.json --pieces examples/pieces.cjs --state .local-state --payload examples/payload.json --run-id ejemplo-1
node dist/cli.cjs examples/flow.json --pieces examples/pieces.cjs --state .local-state --resume ejemplo-1
```

Usar un identificador nuevo para empezar otra ejecución. Reanudar una ejecución ya finalizada devuelve su resultado persistido sin volver a ejecutar las piezas.

### Biblioteca

```js
const { createRuntime, createFileAdapters } = require('./dist/index.cjs');
const flow = require('./examples/flow.json');
const pieces = require('./examples/pieces.cjs');
const runtime = createRuntime({
  pieces,
  ...createFileAdapters('./my-state'),
  projectId: 'my-project',
  secrets: {
    variable: async name => undefined,
    connection: async ({ name, pieceName }) => undefined,
  },
  events: async event => {},
});
async function main() {
  const result = await runtime.execute({ flow, payload: { text: 'hola' }, runId: 'my-run' });
  const recovered = await runtime.resume({ flow, runId: 'my-run' });
  console.log(result, recovered);
}
main().catch(console.error);
```

Los proveedores de secretos del ejemplo devuelven `undefined`: una referencia a un secreto ausente falla explícitamente.

### Contratos de los adaptadores

| Interfaz | Métodos |
|---|---|
| `state` | `load(runId) → snapshot o undefined`; `save(runId, snapshot)` |
| `store` | `get(key)`, `put(key, value)`, `delete(key)` |
| `blobs` | `put({id, data}) → {fileId, readUrl}`; `get(id) → Buffer` |
| `secrets` | `variable(name)`; `connection({name, pieceName})`, con valor de contexto compatible con el SDK |
| `events` | Función async para eventos `checkpoint`, `output`, `response`, `progress` y `log` según la capacidad utilizada |

Los registros de piezas tienen `{name, version, piece}`. La versión del registro debe coincidir exactamente con `settings.pieceVersion` del flujo. Se exportan `createPiece`, `createAction`, `Property` y `PieceAuth` del SDK upstream.

Los archivos locales se escriben mediante temporal, fsync del archivo y rename. La recuperación probada cubre caída de proceso, no fallos de alimentación o corrupción del sistema de archivos. Este adaptador no incorpora leases entre procesos: mantener un solo escritor por ejecución/directorio de estado. JSON es el formato de persistencia; los outputs deben ser serializables en JSON. No se incluyen declaraciones TypeScript propias en este hito.

## Matriz de capacidades actual

| Capacidad | Estado |
|---|---|
| Trigger `EMPTY` con payload del host | Implementado y probado |
| Cadena de acciones `PIECE` confiables | Implementado y probado |
| Referencias de datos `{{trigger.output.text}}` y outputs previos | Probados, incluida referencia a un output restaurado tras una caída |
| Variables del host y censura del input | Implementado y probado |
| Estado, store y blobs inyectados | Implementado; recuperación y store probados |
| Eventos del host | Implementado y probado para checkpoints |
| Una ejecución activa por proceso | Implementado y probado |
| Recuperación desde checkpoint con estado `RUNNING` | Implementado y probado con cierre forzado |
| Ejecución terminal `SUCCEEDED` | Reanuda devolviendo el resultado persistido |
| Reintentar una ejecución terminal fallida | No soportado; no se reinicia silenciosamente |
| Triggers de piezas y programador de eventos | Hito de paridad |
| Routers, bucles, ramas de continue-on-failure | Rechazados por la API inicial; hito de paridad |
| Code y expresiones JavaScript arbitrarias | Deshabilitados explícitamente; requieren adaptador de sandbox |
| Waitpoints y flujos hijos | Sin adaptador; falla explícitamente antes de llamar a la API |
| Aislamiento de piezas, timeout duro y límites de RSS | No implementados; hito de supervisor |
| Julia/ONNX | Hito posterior, sin pruebas de inferencia aquí |

Las piezas se ejecutan como código confiable con los permisos del proceso. Bloquear las llamadas de control de Activepieces no impide el acceso a red o archivos de una pieza que lo haga por cuenta propia. La biblioteca no instala handlers globales ni modifica DNS/sockets al importarse. Los inputs censurados no evitan que una pieza devuelva secretos en su propio output.

## Inventario obtenido

El cierre de dependencias de producción declaradas incluye ocho paquetes, contando el motor:

| Paquete | Función inicial |
|---|---|
| `@activepieces/engine` | Intérprete, operaciones y ejecutores |
| `@activepieces/core-execution` | Tipos y utilidades de ejecución |
| `@activepieces/core-formula` | Expresiones |
| `@activepieces/core-piece-types` | Contratos de piezas |
| `@activepieces/core-utils` | Utilidades comunes |
| `@activepieces/pieces-framework` | SDK de piezas |
| `@activepieces/pieces-common` | Utilidades usadas por piezas |
| `@activepieces/shared` | Esquemas amplios del producto; principal candidato a reducir |

El motor tiene 71 archivos de código bajo `src` en este inventario. Hay 24 archivos con referencias candidatas a servicios/configuración del host. Estas cantidades proceden de un escaneo léxico, no de un grafo de compilación completamente resuelto.

`inventory.json` contiene paquetes, versiones, dependencias externas, referencias y archivos candidatos. No incluye el cierre de herramientas de desarrollo, piezas cargadas dinámicamente ni alias de esbuild. No es un SBOM ni certifica licencias de dependencias.

Para regenerarlo, desde este directorio:

```powershell
node tools/inventory.mjs ../activepieces-audit inventory.json
```

## Arquitectura de destino

```mermaid
flowchart TD
    H[Tu aplicación o CLI] --> R[Runtime: execute / resume / cancel]
    R --> C[Intérprete y contexto por ejecución]
    C --> P[Registro de piezas confiables]
    C --> F[Evaluación de expresiones]
    C --> A[Puertos del host]
    A --> S[Estado y checkpoints]
    A --> B[Archivos y blobs]
    A --> V[Secretos, conexiones y variables]
    A --> W[Waitpoints y respuestas]
    A --> L[Eventos y logs]
    R --> X[Supervisor de procesos y recursos]
```

Los puertos son interfaces inyectadas por el host. Las implementaciones locales servirán para pruebas y CLI; otras podrán usar almacenamiento persistente o servicios de tu aplicación. El núcleo no debe arrancar sockets, modificar globalmente la red ni terminar el proceso al importarse.

## Fronteras concretas que modificar

| Acoplamiento actual | Cambio propuesto |
|---|---|
| `src/main.ts`, `worker-socket.ts` | Conservar como transporte opcional; nuevo entrypoint de biblioteca sin efectos globales |
| `operations/index.ts` | Base para despacho público de operaciones, con validación y errores tipados |
| `api/engine-file-api.ts`, `api/engine-run-api.ts` | Inyectar almacenamiento de blobs y estado de ejecución |
| `helper/flow-run-progress-reporter.ts` | Reporter por ejecución; separar eventos de UI y checkpoints durables |
| `handler/context/engine-constants.ts` | Configuración explícita; sustituir consultas de proyecto por servicios del host |
| `handler/context/flow-execution-context.ts` | Conservar semántica, inyectar almacenamiento de fragmentos de logs |
| `piece-context/*` | Adaptadores de conexiones, variables, store, flujos y waitpoints |
| Carga e instalación de piezas | Registro de versiones fijadas y aprobadas; instalación fuera de la ejecución |
| SSRF, procesos y `process.env` | Políticas aplicadas por el host y supervisor, configuración validada al crear runtime |
| `@activepieces/shared` | Extraer los contratos utilizados a un paquete de esquemas del runtime, conservando compatibilidad |

El reporter actual contiene estado a nivel de módulo. La primera versión debe admitir una ejecución activa por proceso hasta eliminar y probar esos acoplamientos. El modelo de concurrencia debe ser explícito: reutilización de proceso no equivale a seguridad para ejecuciones simultáneas.

## Hoja de ruta restante

Los hitos siguientes mantienen el diseño de extracción. El primer runtime funciona; todavía no se ejecutó la suite completa upstream ni se demuestra paridad con todas sus capacidades. Las pruebas de este proyecto verifican el alcance del primer hito.

### 1. Baseline reproducible

- Importar el motor y el cierre necesario desde el commit fijado, preservando MIT y procedencia.
- Resolver alias de compilación y dependencias de desarrollo; generar lockfile propio.
- Compilar y ejecutar las pruebas upstream relevantes antes de cambiar semánticas.
- Auditar referencias efectivas para impedir inclusión accidental de directorios Enterprise.

**Entrega:** build reproducible de la base y conjunto de pruebas de referencia. Todavía puede mantener dependencias de producto.

### 2. Runtime local independiente

- Entry point de biblioteca y CLI.
- Contexto por ejecución y puertos del host; adapters locales de estado, blobs y secretos.
- Trigger con payload proporcionado por el host y una pieza local sencilla.
- Deshabilitar explícitamente capacidades sin adaptador; nunca fingir éxito ni devolver secretos vacíos.

**Entrega:** flujo trigger → pieza → resultado en un proceso local, con cero llamadas a la API de Activepieces. Importar la biblioteca no abre conexiones ni altera handlers globales.

### 3. Paridad del intérprete

- Expresiones, routers, bucles, errores y reintentos.
- Pausa, reanudación y waitpoints mediante almacenamiento durable.
- Compatibilidad de versiones del flujo y de piezas; fixtures upstream y pruebas diferenciales.

**Entrega:** matriz de capacidades soportadas y errores claros para las restantes. Eliminar `shared` solo después de verificar equivalencia de los esquemas extraídos.

### 4. Mejoras operativas

- Checkpoints por paso con confirmación durable, detección de conflictos y versionado del estado.
- Idempotencia por ejecución y ruta de paso, incluyendo iteraciones de bucles.
- Cancelación, timeout del supervisor y límites de memoria total mediante contenedores/cgroups.
- Aislamiento y políticas de red según confianza del código.
- Redacción de secretos, métricas y límites de tamaño de logs.

Un checkpoint después de una acción no elimina la ventana entre un efecto externo y la escritura del checkpoint. La idempotencia debe apoyarse también en el destino o en un mecanismo transaccional adecuado; no prometer ejecución exactamente una vez para cualquier integración.

### 5. Pieza Julia

- Runtime ONNX nativo y archivos del modelo con procedencia/versiones fijadas.
- Caché por proceso limitada y verificable; carga explícita fuera del camino de cada acción.
- Medir primera carga, latencia caliente, RSS y consumo con una y varias ejecuciones.

**Entrega:** inferencia local dentro de una pieza del motor extraído, validada en la plataforma elegida. El desarrollo inicial puede hacerse aquí; dependencias nativas y límites deben probarse también en Linux antes de desplegar al VPS.

## Pruebas que deben decidir si la extracción funciona

1. Flujo local real sin servidor de Activepieces ni servicios remotos de control.
2. Mismos resultados que upstream para fixtures de expresión, router y bucle.
3. Dos ejecuciones con contextos y secretos distintos no intercambian estado.
4. Matar el proceso antes y después de un checkpoint y verificar la recuperación.
5. Reanudación de un bucle sin saltar o duplicar iteraciones persistidas.
6. Cancelación y timeout detienen código y procesos hijos, con estados observables.
7. Logs y fallos no exponen credenciales.
8. Para Julia: medir memoria nativa, recargas del modelo y saturación del worker.

## Evidencia del primer hito

- `UPSTREAM.json`, `UPSTREAM-FILES.json` y `NOTICE.md`: origen y preservación de fuentes/licencia.
- `tools/build.mjs`: fronteras sustituidas; el build falla si se incluye código de arranque de servidor o directorios Enterprise comprobados.
- `src/index.mjs`: API real sobre el intérprete upstream, registro de piezas y recuperación.
- `src/ports/`: proveedores del host, bloqueo de API y error explícito para Code no adaptado.
- `src/adapters.mjs`: persistencia local de estado, store y blobs.
- `test/runtime.test.cjs`: nueve pruebas, incluida caída forzada y recuperación en otra instancia/proceso.
- `VERIFICATION.md`: resultados de las comprobaciones realizadas.

Pendiente para ampliar el producto: reducir `shared`, demostrar paridad, incorporar supervisor y políticas de red, implementar waitpoints y adaptar Julia. Estas ampliaciones no forman parte del primer hito terminado.
