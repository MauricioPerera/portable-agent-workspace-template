# Source attribution

`vendor/activepieces/` contains source copied without changes from Activepieces, commit `2d5a47708c87e3ce17116d2d4b34d4d1208e8cd2`, https://github.com/activepieces/activepieces.

The original license and copyright notices are retained in `vendor/activepieces/LICENSE`. Its MIT grant covers the copied package directories. Neither `packages/ee/` nor `packages/server/api/src/app/ee/` is copied. Enterprise license references in the preserved root license describe excluded upstream directories.

`tools/build.mjs` documents build-time adaptations: injected host ports, disabled native Code sandbox and fail-closed checkpoint errors. Upstream source files are retained for comparison and future parity work. New files implement the standalone integration.

Npm dependencies retain their own licenses and notices in their installed packages. A redistribution must retain the applicable notices for the dependencies actually shipped. This notice is not a full third-party license audit.
